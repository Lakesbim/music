import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:blackhole/Helpers/mediaitem_converter.dart';
import 'package:hive/hive.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:rxdart/rxdart.dart';

class AudioPlayerTask extends BackgroundAudioTask {
  final _equalizer = AndroidEqualizer();
  AndroidEqualizerParameters _equalizerParams;

  AudioPlayer _player;

  setAudioPlayer() {
    _player = AudioPlayer(
      handleInterruptions: true,
      androidApplyAudioAttributes: true,
      handleAudioSessionActivation: true,
      audioPipeline: AudioPipeline(
        androidAudioEffects: [
          _equalizer,
        ],
      ),
    );
  }

  Timer _sleepTimer;
  StreamSubscription<PlaybackEvent> _eventSubscription;
  String preferredQuality;
  List<MediaItem> queue = [];
  bool shuffle = false;
  List<MediaItem> defaultQueue = [];
  ConcatenatingAudioSource concatenatingAudioSource;

  int index;
  bool offline;
  MediaItem get mediaItem => index == null ? queue[0] : queue[index];

  Future<void> onTaskRemoved() async {
    bool stopForegroundService =
        Hive.box('settings').get('stopForegroundService') ?? true;
    if (stopForegroundService) {
      await onStop();
    }
  }

  initiateBox() async {
    try {
      await Hive.initFlutter();
    } catch (e) {}
    try {
      await Hive.openBox('settings');
    } catch (e) {
      print('Failed to open Settings Box');
      print("Error: $e");
      Directory dir = await getApplicationDocumentsDirectory();
      String dirPath = dir.path;
      String boxName = "settings";
      File dbFile = File('$dirPath/$boxName.hive');
      File lockFile = File('$dirPath/$boxName.lock');
      await dbFile.delete();
      await lockFile.delete();
      await Hive.openBox("settings");
    }
    try {
      await Hive.openBox('recentlyPlayed');
    } catch (e) {
      print('Failed to open Recent Box');
      print("Error: $e");
      Directory dir = await getApplicationDocumentsDirectory();
      String dirPath = dir.path;
      String boxName = "recentlyPlayed";
      File dbFile = File('$dirPath/$boxName.hive');
      File lockFile = File('$dirPath/$boxName.lock');
      await dbFile.delete();
      await lockFile.delete();
      await Hive.openBox("recentlyPlayed");
    }
  }

  addRecentlyPlayed(MediaItem mediaitem) async {
    if (mediaItem.artUri.toString().startsWith('https://img.youtube.com'))
      return;
    List recentList;
    try {
      recentList = await Hive.box('recentlyPlayed').get('recentSongs').toList();
    } catch (e) {
      recentList = null;
    }

    Map item = MediaItemConverter().mediaItemtoMap(mediaItem);
    recentList == null ? recentList = [item] : recentList.insert(0, item);

    final jsonList = recentList.map((item) => jsonEncode(item)).toList();
    final uniqueJsonList = jsonList.toSet().toList();
    recentList = uniqueJsonList.map((item) => jsonDecode(item)).toList();

    if (recentList.length > 30) {
      recentList = recentList.sublist(0, 30);
    }
    Hive.box('recentlyPlayed').put('recentSongs', recentList);
  }

  @override
  Future<void> onStart(Map<String, dynamic> params) async {
    index = params['index'];
    offline = params['offline'];
    preferredQuality = params['quality'];
    await initiateBox();
    await setAudioPlayer();

    final session = await AudioSession.instance;
    await session.configure(AudioSessionConfiguration.music());

    _player.currentIndexStream.distinct().listen((idx) {
      if (idx != null && queue.isNotEmpty) {
        index = idx;
        AudioServiceBackground.setMediaItem(queue[idx]);
      }
    });

    // _player.sequenceStateStream.distinct().listen((state) {
    // if (state != null) {
    // MediaItem mediaItem = state.currentSource.tag;
    // AudioServiceBackground.setMediaItem(mediaItem);
    // index = queue.indexWhere((element) => element == mediaItem);
    // }
    // });

    _eventSubscription = _player.playbackEventStream.listen((event) {
      _broadcastState();
    });

    _player.processingStateStream.listen((state) {
      if (state == ProcessingState.completed) {
        AudioService.stop();
      }
    });
  }

  @override
  Future<void> onSkipToQueueItem(String mediaId) async {
    final newIndex = queue.indexWhere((item) => item.id == mediaId);
    if (newIndex == -1) return;
    index = newIndex;
    _player.seek(Duration.zero, index: newIndex);
    if (!offline) addRecentlyPlayed(queue[newIndex]);
  }

  @override
  Future<void> onUpdateQueue(List<MediaItem> _queue) async {
    await AudioServiceBackground.setQueue(_queue);
    await AudioServiceBackground.setMediaItem(_queue[index]);
    concatenatingAudioSource = ConcatenatingAudioSource(
      children: _queue
          .map((item) => AudioSource.uri(
              offline
                  ? Uri.file(item.extras['url'])
                  : Uri.parse(item.extras['url'].replaceAll(
                      "_96.", "_${preferredQuality.replaceAll(' kbps', '')}.")),
              tag: item))
          .toList(),
    );
    await _player.setAudioSource(concatenatingAudioSource);
    await _player.seek(Duration.zero, index: index);
    queue = _queue;
  }

  @override
  Future<void> onAddQueueItemAt(MediaItem mediaItem, int addIndex) async {
    if (addIndex == -1)
      addIndex = queue.indexWhere((item) => item == queue[index]) + 1;
    await concatenatingAudioSource.insert(
        addIndex,
        AudioSource.uri(
            offline
                ? Uri.file(mediaItem.extras['url'])
                : Uri.parse(mediaItem.extras['url'].replaceAll(
                    "_96.", "_${preferredQuality.replaceAll(' kbps', '')}.")),
            tag: mediaItem));
    queue.insert(addIndex, mediaItem);
    await AudioServiceBackground.setQueue(queue);
  }

  Future<void> onAddQueueList(List<MediaItem> mediaItemList) async {
    await concatenatingAudioSource.addAll(mediaItemList
        .map((item) => AudioSource.uri(
            offline
                ? Uri.file(item.extras['url'])
                : Uri.parse(item.extras['url'].replaceAll(
                    "_96.", "_${preferredQuality.replaceAll(' kbps', '')}.")),
            tag: item))
        .toList());
    queue.addAll(mediaItemList);
    await AudioServiceBackground.setQueue(queue);
  }

  @override
  Future<void> onAddQueueItem(MediaItem mediaItem) async {
    await concatenatingAudioSource.add(AudioSource.uri(
        offline
            ? Uri.file(mediaItem.extras['url'])
            : Uri.parse(mediaItem.extras['url'].replaceAll(
                "_96.", "_${preferredQuality.replaceAll(' kbps', '')}.")),
        tag: mediaItem));
    queue.add(mediaItem);
    await AudioServiceBackground.setQueue(queue);
  }

  @override
  Future<void> onRemoveQueueItem(MediaItem mediaItem) async {
    final removeIndex = queue.indexWhere((item) => item == mediaItem);
    queue.remove(mediaItem);
    await concatenatingAudioSource.removeAt(removeIndex);
    await AudioServiceBackground.setQueue(queue);
  }

  Future<void> onReorderQueue(int oldIndex, int newIndex) async {
    concatenatingAudioSource.move(oldIndex, newIndex);
    MediaItem item = queue.removeAt(oldIndex);
    queue.insert(newIndex, item);
    await AudioServiceBackground.setQueue(queue);
  }

  @override
  Future<void> onPlay() async {
    if (!offline) addRecentlyPlayed(queue[index]);
    _player.play();
  }

  @override
  Future<dynamic> onCustomAction(String myFunction, dynamic myVariable) {
    if (myFunction == 'sleepTimer') {
      _sleepTimer?.cancel();
      if (myVariable.runtimeType == int &&
          myVariable != null &&
          myVariable > 0) {
        _sleepTimer = Timer(Duration(minutes: myVariable), () {
          onStop();
        });
      }
    }

    if (myFunction == 'addListToQueue') {
      List temp = myVariable;
      MediaItemConverter converter = MediaItemConverter();
      List<MediaItem> mediaItemList =
          temp.map((item) => converter.mapToMediaItem(item)).toList();
      onAddQueueList(mediaItemList);
    }

    if (myFunction == 'setBandGain') {
      final bandIdx = myVariable['band'] as int;
      final gain = myVariable['gain'] as double;
      _equalizerParams.bands[bandIdx].setGain(gain);
    }

    if (myFunction == 'reorder') {
      onReorderQueue(myVariable[0], myVariable[1]);
    }

    if (myFunction == 'setEqualizer') {
      _equalizer.setEnabled((myVariable));
    }

    if (myFunction == 'getEqualizerParams') {
      return getEqParms();
    }

    return Future.value(true);
  }

  Future<Map> getEqParms() async {
    if (_equalizerParams == null)
      _equalizerParams = await _equalizer.parameters;
    List<AndroidEqualizerBand> bands = _equalizerParams.bands;
    List<Map> bandList = bands
        .map((e) => {
              'centerFrequency': e.centerFrequency,
              'gain': e.gain,
              'index': e.index
            })
        .toList();

    return {
      'maxDecibels': _equalizerParams.maxDecibels,
      'minDecibels': _equalizerParams.minDecibels,
      'bands': bandList
    };
  }

  @override
  Future<void> onSetRepeatMode(AudioServiceRepeatMode repeatMode) {
    switch (repeatMode) {
      case AudioServiceRepeatMode.all:
        _player.setLoopMode(LoopMode.all);
        break;

      case AudioServiceRepeatMode.one:
        _player.setLoopMode(LoopMode.one);
        break;
      default:
        _player.setLoopMode(LoopMode.off);
        break;
    }

    return super.onSetRepeatMode(repeatMode);
  }

  @override
  Future<void> onSetShuffleMode(AudioServiceShuffleMode shuffleMode) async {
    switch (shuffleMode) {
      case AudioServiceShuffleMode.none:
        queue = defaultQueue;
        _player.setShuffleModeEnabled(false);
        AudioServiceBackground.setQueue(queue);
        break;
      case AudioServiceShuffleMode.group:
        break;
      case AudioServiceShuffleMode.all:
        defaultQueue = queue;
        await _player.setShuffleModeEnabled(true);
        await _player.shuffle();
        _player.sequenceStateStream
            .map((state) => state?.effectiveSequence)
            .distinct()
            .map((sequence) =>
                sequence.map((source) => source.tag as MediaItem).toList())
            .listen(AudioServiceBackground.setQueue);
        break;
    }
  }

  @override
  Future<void> onClick(MediaButton button) {
    switch (button) {
      case MediaButton.next:
        onSkipToNext();
        break;
      case MediaButton.previous:
        onSkipToPrevious();
        break;
      case MediaButton.media:
        _handleMediaActionPressed();
        break;
    }
    return Future.value();
  }

  BehaviorSubject<int> _tappedMediaActionNumber;
  Timer _timer;

  void _handleMediaActionPressed() {
    if (_timer == null) {
      _tappedMediaActionNumber = BehaviorSubject.seeded(1);
      _timer = Timer(Duration(milliseconds: 600), () {
        final tappedNumber = _tappedMediaActionNumber.value;
        if (tappedNumber == 1) {
          if (AudioServiceBackground.state.playing)
            onPause();
          else
            onPlay();
        } else if (tappedNumber == 2) {
          onSkipToNext();
        } else {
          onSkipToPrevious();
        }

        _tappedMediaActionNumber.close();
        _timer.cancel();
        _timer = null;
      });
    } else {
      final current = _tappedMediaActionNumber.value;
      _tappedMediaActionNumber.add(current + 1);
    }
  }

  @override
  Future<void> onPause() => _player.pause();

  @override
  Future<void> onSeekTo(Duration position) => _player.seek(position);

  @override
  Future<void> onStop() async {
    await _player.dispose();
    _eventSubscription.cancel();
    await _broadcastState();
    await super.onStop();
  }

  /// Broadcasts the current state to all clients.
  Future<void> _broadcastState() async {
    await AudioServiceBackground.setState(
      controls: [
        MediaControl.skipToPrevious,
        if (_player.playing) MediaControl.pause else MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      systemActions: [
        MediaAction.seekTo,
        MediaAction.seekForward,
        MediaAction.seekBackward,
      ],
      androidCompactActions: [0, 1, 2],
      processingState: _getProcessingState(),
      playing: _player.playing,
      position: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
    );
  }

  /// Maps just_audio's processing state into into audio_service's playing state.
  AudioProcessingState _getProcessingState() {
    switch (_player.processingState) {
      case ProcessingState.idle:
        return AudioProcessingState.stopped;
      case ProcessingState.loading:
        return AudioProcessingState.connecting;
      case ProcessingState.buffering:
        return AudioProcessingState.buffering;
      case ProcessingState.ready:
        return AudioProcessingState.ready;
      case ProcessingState.completed:
        return AudioProcessingState.completed;
      default:
        throw Exception("Invalid state: ${_player.processingState}");
    }
  }
}
