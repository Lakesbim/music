package com.shadow.blackhole

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
